/*
import java.util.Scanner;

public class Main {
    static void main() {
        Scanner num1 = new Scanner(System.in);
        System.out.println("Enter first number: ");
        int number1 = num1.nextInt();
        System.out.println("First number is: " + number1);
        //
        System.out.println("*************************************");
        //
        Scanner num2 = new Scanner(System.in);
        System.out.println("Enter second number: ");
        int number2 = num2.nextInt();
        System.out.println("Second number is: " + number2);
        //
        System.out.println("*************************************");
        //
        Scanner choice = new Scanner(System.in);
        System.out.println("""
        What would you like to do with these two numbers?
        *****
        - Divide
        - Add
        - Subtract
        - Multiply
        *****
        Enter Choice:
        """);
        String selection = choice.nextLine();
        //
        if (selection.equalsIgnoreCase("divide")) {
            int total = number1 / number2;
            System.out.println(number1+"÷"+number2+"="+total);
        }
        //
        if (selection.equalsIgnoreCase("add")) {
            int total = number1 + number2;
            System.out.println(number1+"+"+number2+"="+total);
        }
        //
        if (selection.equalsIgnoreCase("subtract")) {
            int total = number1 - number2;
            System.out.println(number1+"-"+number2+"="+total);
        }
        //
        if (selection.equalsIgnoreCase("multiply")) {
            int total = number1 * number2;
            System.out.println(number1+"x"+number2+"="+total);
        }
    }
}
*/


/*
import java.util.Scanner;

public class Main {
    static void main() {
        Main main = new Main();
        Scanner choice = new Scanner(System.in);
        System.out.println("""
                What calculation do you want to perform?
                *****
                1 - Celsius -> Fahrenheit
                2 - Fahrenheit -> Celsius 
                *****
                Enter Choice:
                """);
        float selection = choice.nextFloat();

        // this one does Celsius -> Fahrenheit
        if (selection == 1) {
            System.out.println("Enter temperature in °C: ");
            float tempCelsius = choice.nextFloat();
            float totalFahrenheit = (tempCelsius * 9 / 5) + 32;
            System.out.printf("%.1f°C = %.1f°F%n", tempCelsius, totalFahrenheit);
        }

        // this one does Fahrenheit -> Celsius
        if (selection == 2) {
            System.out.println("Enter temperature in °F: ");
            float tempFahrenheit = choice.nextFloat();
            float totalCelsius = (tempFahrenheit - 32) * 5 / 9;
            System.out.printf("%.1f°F = %.1f°C%n", tempFahrenheit, totalCelsius);

        }
    }
}
*/

public class Main {
    static void main() {

    }
}