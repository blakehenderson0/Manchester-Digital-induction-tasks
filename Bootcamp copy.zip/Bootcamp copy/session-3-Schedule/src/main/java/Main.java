import jdk.swing.interop.SwingInterOpUtils;

import java.util.Scanner;

public class Main {
    static void main() {

        String[] shotNames = { "Hole in one!", "Eagle", "Birdie", "Par", "Bogey", "Double Bogey", "Quit" };

        int par = 4;


        Scanner scanner = new Scanner(System.in);

        System.out.println("--------------");
        System.out.println("Par = 4");
        System.out.println("--------------");
        System.out.println("How many strokes did you pot the ball in?:  ");
        int strokes = scanner.nextInt();

        if (strokes == 1) {
            System.out.println(shotNames[0]);
        }

        if (strokes == 2) {
                System.out.println(shotNames[1]);
        }

        if (strokes == 3) {
            System.out.println(shotNames[2]);
        }

        if (strokes == 4) {
            System.out.println(shotNames[3]);
        }

        if (strokes == 5) {
            System.out.println(shotNames[4]);
        }

        if (strokes == 6) {
            System.out.println(shotNames[5]);
        }

        if (strokes == 7) {
            System.out.println(shotNames[6]);
        }

        scanner.close();

    }
}
