import static org.junit.jupiter.api.Assertions.*;

public class PasswordCheckerTest {
    @Test
    void checkBlankPasswordReturnsFalse() {
        PasswordChecker checker = new PasswordChecker():

        boolean result = checker.checkPassword("");

        assertFalse(result);

    }

    @Test
    void checkEightCharacterPasswordReturnsTrue() {

    }
}
