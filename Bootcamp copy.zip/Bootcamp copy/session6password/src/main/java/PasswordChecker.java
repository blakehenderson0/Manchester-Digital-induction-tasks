public class PasswordChecker {
    boolean checkPassword(String password); {

    }
}
