import jdk.swing.interop.SwingInterOpUtils;

import java.util.Scanner;

public class Main {
    static void main() {

        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a day of week from 1-7: ");
        int day = scanner.nextInt();

        if (day == 1) {
            System.out.println("The day is Monday, you have nothing planned.");
        }

        if (day == 2) {
                System.out.println("The day is Tuesday, you are going to the Gym.");
        }

        if (day == 3) {
            System.out.println("The day is Wednesday, you have nothing planned.");
        }

        if (day == 4) {
            System.out.println("The day is Thursday, you are going to the Gym.");
        }

        if (day == 5) {
            System.out.println("The day is Friday, you have nothing planned.");
        }

        if (day == 6) {
            System.out.println("The day is Saturday, you have nothing planned.");
        }

        if (day == 7) {
            System.out.println("The day is Sunday, you are doing Gardening.");
        }



        scanner.close();
/*
        if ()
            System.out.println("Today is Thursday");
*/
    }
}
