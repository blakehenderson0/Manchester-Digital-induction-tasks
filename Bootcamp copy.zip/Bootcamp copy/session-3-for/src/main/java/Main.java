import java.util.Scanner;
public class Main {

    static void main() {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter an hour (0-23): ");
        int hour = sc.nextInt();

        int cost;

        if (hour >= 0 && hour < 5) {
            cost = 300;
        } else if (hour >= 5 && hour < 10) {
            cost = 350;
        } else if (hour >= 10 && hour < 15) {
            cost = 500;
        } else if (hour >= 15 && hour < 20) {
            cost = 700;
        } else if (hour >= 20 && hour <= 23) {
            cost = 400;
        } else {
            System.out.println("Invalid hour");
            return;
        }

        System.out.println("Total parking cost is " + cost);
    }
}