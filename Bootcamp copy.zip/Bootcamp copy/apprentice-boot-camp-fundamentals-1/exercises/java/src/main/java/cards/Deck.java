package cards;

public class Deck {
    void shuffle() {

    }

    Card deal() {
        return null;
    }

    String[] getCards() {
        return null;
    }
}
