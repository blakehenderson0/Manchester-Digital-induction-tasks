package cards;

public class Card {
    boolean snap(Card othercard) {
        return false;
    }
}
