import java.util.Arrays;
import java.util.Random;
import java.util.stream.IntStream;

public class Football {
    static void main() {
        int[] x = IntStream.generate(() -> new Random().nextInt(5)).limit(38).toArray();
        int[] y = IntStream.generate(() -> new Random().nextInt(5)).limit(38).toArray();
//        System.out.println("x:");
//        System.out.println(Arrays.toString(x));
//        System.out.println("y:");
//        System.out.println(Arrays.toString(y));

        int points = 0;
        int win = 0;
        int draw = 0;
        int loss = 0;

        for (int i = 0; i < x.length; i++) {
            if (x[i] > y[i]) {
                points += 3;
                win++;
            } else if (x[i] == y[i]) {
                points += 1;
                draw++;
            } else if (x[i] < y[i]) {
                points += 0;
                loss++;
            } else {
                System.out.println("something somehow went wrong gg");
            }
        }
        System.out.println("*****************");
        System.out.println("***** Stats *****");
        System.out.println("*****************");
        System.out.println("Out of 38 games:");
        System.out.println("Wins= " + win);
        System.out.println("Draws= " + draw);
        System.out.println("Losses= " + loss);
        System.out.println("*****************");
        System.out.println("Total Points= " + points);
        System.out.println("*****************");

    }
}
