public class Calculator {

    public int divide(int a, int b) {
        if (b == 0) {
            throw new IllegalArgumentException("Unable to divide by zero");
        }
        return a / b;
    }
}