public class Main{
        public static int sequenceSum(int begin, int end, int step) {
            if (begin > end) {
                return 0;
            }

            int total = 0;

            for (int current = total + 2;
                 current <= begin;
                 current += step) {


            }

            return total;
        }
}


