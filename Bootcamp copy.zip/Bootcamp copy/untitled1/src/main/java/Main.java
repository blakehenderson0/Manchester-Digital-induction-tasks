public class Main {
    static void Main() {

        int[] shots = new int[]{0};
        System.out.println();


    }
}